![Swipe View](https://github.com/julapy/ofxColorPicker/raw/master/example/image/ofxColorPicker.png)

this addon has a dependency on ofxMSAInteractiveObject.
a copy of ofxMSAInteractiveObject can be found in the addons folder of this example.
the original ofxMSAInteractiveObject addon can be found here, [https://github.com/memo/msalibs](https://github.com/memo/msalibs)